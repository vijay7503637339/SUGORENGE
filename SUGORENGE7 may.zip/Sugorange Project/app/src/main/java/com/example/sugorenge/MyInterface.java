package com.example.sugorenge;

public interface MyInterface {

    public void foo(int count ,int total);
}
